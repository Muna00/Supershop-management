
<?php
include "searchbtn.php";
$connect=mysqli_connect("localhost","root","","test");
$search=$_POST["search"];
$output='';
$sql="SELECT * FROM products WHERE sale_price LIKE'%$search%'";
$result=mysqli_query($connect,$sql);
if(mysqli_num_rows($result)>0){
    $output .='<h4 align="center">Search Result</h4>';
    $output .='<div class="table-responsive">
    <table class="table table bordered">
    <tr>
    <th> <span> Product Name </span> </th>
    <th>  Product quantity  </th>
    <th>  buy price  </th>
    <th>  selling price  </th>
    
    </tr>';

while($row=mysqli_fetch_array($result))
{
    $output .='
    <tr>
    <td>' .$row["name"].'</td>
    <td>' .$row["quantity"].'</td>
    <td>' .$row["buy_price"].'</td>
    <td>' .$row["sale_price"].'</td>
    </tr>
    ';
}
echo $output;
}else{
    echo 'data not found';
}
?>


              