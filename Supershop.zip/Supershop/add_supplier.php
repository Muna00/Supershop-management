<?php
  $page_title = 'Add Supplier';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
?>
<?php
if(isset($_POST['add_supplier'])){

    $req_fields = array('sname','sadress','sdealer');
    validate_fields($req_fields);
    if(empty($errors)){
        $name   = remove_junk($db->escape($_POST['sname']));
        $address   = remove_junk($db->escape($_POST['saddress']));
        $dealer   = remove_junk($db->escape($_POST['sdealer']));
       
        $query  = "INSERT INTO supplier (";
        $query .="sname,saddress,sdealer";
        $query .=") VALUES (";
        $query .=" '{$name}', '{$address}','{$dealer}'";
        $query .=")";
        if($db->query($query)){
            //sucess
            $session->msg('s',"Supplier has been added! ");
            redirect('add_supplier.php', false);
          } else {
            //failed
            $session->msg('d',' Sorry failed to add Supplier!');
            redirect('add_supplier.php', false);
          }
     } else {
       $session->msg("d", $errors);
        redirect('add_supplier.php',false);
     }
   }
  ?>

<?php include_once('layouts/header.php'); ?>
<div class="login-page">
    <div class="text-center">
       <h3>Add new supplier</h3>
     </div>
     <?php echo display_msg($msg); ?>
      <form method="post" action="add_supplier.php" class="clearfix">
        <div class="form-group">
              <label for="name" class="control-label">Supplier Name</label>
              <input type="text" class="form-control" name="sname">
        </div>
        
        <div class="form-group">
              <label for="address" class="control-label">Address</label>
              <input type="text" class="form-control" name="saddress">
        </div>
        <div class="form-group">
              <label for="dealer" class="control-label">Dealer Name</label>
              <input type="text" class="form-control" name="sdealer">
        </div>
       
       
       
        <div class="form-group clearfix">
                <button type="submit" name="add" class="btn btn-info">Update</button>
        </div>
    </form>
</div>

<?php include_once('layouts/footer.php'); ?>
