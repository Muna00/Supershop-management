<?php
  $page_title = 'Edit Supplier';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
?>
<?php
  $e_supplier = find_by_id('supplier',(int)$_GET['id']);
  if(!$e_supplier){
    $session->msg("d","Missing Supplier id.");
    redirect('supplier.php');
  }
?>

<?php
if(isset($_POST['update'])){

    $req_fields = array('sname','sadress','sdealer');
    validate_fields($req_fields);
    if(empty($errors)){
        $name   = remove_junk($db->escape($_POST['sname']));
        $address   = remove_junk($db->escape($_POST['saddress']));
        $dealer   = remove_junk($db->escape($_POST['sdealer']));
      
        $query  = "UPDATE supplier SET ";
        $query .= "sname='{$name}',saddress='{$address}',sdealer='{$dealer}'";
        $query .= "WHERE ID='{$db->escape($e_supplier['id'])}'";
        $result = $db->query($query);

        if($result && $db->affected_rows() === 1){
            //sucess
            $session->msg('s',"Supplier has been updated! ");
            redirect('edit_supplier.php?id='.(int)$e_supplier['id'], false);
          } else {
            //failed
            $session->msg('d',' Sorry failed to update!');
            redirect('edit_supplier.php?id='.(int)$e_supplier['id'], false);
          }
     } else {
       $session->msg("d", $errors);
      redirect('edit_supplier.php?id='.(int)$e_supplier['id'], false);
     }
   }
  ?>

<?php include_once('layouts/header.php'); ?>
<div class="login-page">
    <div class="text-center">
       <h3>Edit Supplier</h3>
     </div>
     <?php echo display_msg($msg); ?>
      <form method="post" action="edit_supplier.php?id=<?php echo (int)$e_supplier['id'];?>" class="clearfix">
        <div class="form-group">
              <label for="name" class="control-label">Supplier Name</label>
              <input type="name" class="form-control" name="sname" value="<?php echo remove_junk(ucwords($e_supplier['sname'])); ?>">
        </div>
        <div class="form-group">
              <label for="address" class="control-label">Supplier Address</label>
              <input type="text" class="form-control" name="saddress" value="<?php echo remove_junk(ucwords($e_supplier['saddress'])); ?>">
        </div>
        <div class="form-group">
              <label for="dealer" class="control-label">Dealer Name</label>
              <input type="name" class="form-control" name="sdealer" value="<?php echo remove_junk(ucwords($e_supplier['sdealer'])); ?>">
        </div>
       
        <div class="form-group clearfix">
                <button type="submit" name="update" class="btn btn-info">Update</button>
        </div>
    </form>
</div>

<?php include_once('layouts/footer.php'); ?>
